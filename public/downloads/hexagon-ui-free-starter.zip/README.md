# Hexagon UI — free starter (10 blocks)

Downloaded from the marketing site. Same tokens and motion patterns as the full kit.

## Requirements

- React 18+ or 19+
- Tailwind CSS v4 with semantic tokens (`blocks/tokens/hexagon-ui-variables.css`)
- `lucide-react`, `framer-motion` (client blocks)
- Map `@/components/blocks` → `./blocks`, `@/components/layout` → `./layout`, `@/lib` → `./lib`

## Suggested page order

1. `announcement-bar`
2. `hero-marketing`
3. `trust-strip`
4. `feature-grid`
5. `stats-strip`
6. `social-proof-quote`
7. `pricing-single`
8. `faq-accordion`
9. `cta-band`
10. `footer-simple`

## Full kit

Upgrade on Gumroad for the complete block library. Regenerate this ZIP locally with `npm run kit:zip:free`.

/** Free starter subset — 10 sections */
export * from "./announcement-bar";
export * from "./hero-marketing";
export * from "./trust-strip";
export * from "./feature-grid";
export * from "./stats-strip";
export * from "./social-proof-quote";
export * from "./pricing-single";
export * from "./faq-accordion";
export * from "./cta-band";
export * from "./footer-simple";
